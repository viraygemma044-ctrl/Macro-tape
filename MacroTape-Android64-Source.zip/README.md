# MacroTape (Android64 build project)

MacroTape is an experimental Geometry Dash Geode mod for **GD 2.2081 on Android ARM64**.

## Features in this prototype

- `REC`: record player button press/release events and frame order.
- `SAVE`: write the macro to `macro.csv` in the mod's save directory.
- `LOAD`: load a saved macro.
- `PLAY`: replay the loaded macro from the current level position.
- `STOP`: stop recording/playback and release player buttons to reduce stuck-input risk.
- Records player 1/player 2 separately for dual mode.

## Build Android64

This project uses the official Geode GitHub Actions builder. It requires a successful remote build before an installable `.geode` package exists; the ZIP itself is source code, not a compiled mod.

1. Create a GitHub repository for this project and upload these files while preserving their folder structure.
2. Open the repository's **Actions** tab and run **Build MacroTape Android64**, or push a commit to trigger it.
3. Open the successful workflow run and download the `MacroTape-Android64` artifact. It contains the `.geode` package built for Android ARM64, including the `myname.macrotape.android64.so` native library.
4. Install it through Geode on an ARM64 Android installation of Geometry Dash 2.2081.

## Important limitations

- This is an experimental prototype. It has **not** been compiled or tested in-game in this environment.
- Macro playback depends on game timing and can desync if the level, starting position, physics, or game state differs from the recording.
- Test offline first. Do not assume it is a verified TAS or deterministic replay tool.
- SDK version is set to Geode 5.11.2, which targets the 2.2081 bindings in the official build workflow.
