#include <Geode/Geode.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/PlayerObject.hpp>

#include <algorithm>
#include <fstream>
#include <sstream>
#include <string>
#include <utility>
#include <vector>

using namespace geode::prelude;

namespace {
    struct MacroEvent {
        int frame = 0;
        int button = 0;
        bool down = false;
        bool player2 = false;
    };

    std::vector<MacroEvent> g_events;
    int g_frame = 0;
    size_t g_playIndex = 0;
    bool g_recording = false;
    bool g_playing = false;

    auto macroPath() {
        return Mod::get()->getSaveDir() / "macro.csv";
    }

    bool isKnownPlayer(PlayerObject* player) {
        auto layer = PlayLayer::get();
        return layer && player &&
            (layer->m_player1 == player || layer->m_player2 == player);
    }

    bool isPlayer2(PlayerObject* player) {
        auto layer = PlayLayer::get();
        return layer && layer->m_player2 == player;
    }

    void recordEvent(PlayerObject* player, PlayerButton button, bool down) {
        if (!g_recording || g_playing || !isKnownPlayer(player)) return;

        g_events.push_back({
            g_frame,
            static_cast<int>(button),
            down,
            isPlayer2(player)
        });
    }

    bool saveMacro() {
        auto path = macroPath();
        std::ofstream out(path.string(), std::ios::out | std::ios::trunc);
        if (!out) {
            log::error("MacroTape: could not open macro file for writing");
            return false;
        }

        out << "# MacroTape CSV v1\n";
        out << "# frame,button,down,player2\n";
        for (auto const& event : g_events) {
            out << event.frame << ','
                << event.button << ','
                << (event.down ? 1 : 0) << ','
                << (event.player2 ? 1 : 0) << '\n';
        }
        out.flush();
        return static_cast<bool>(out);
    }

    bool loadMacro() {
        std::ifstream in(macroPath().string());
        if (!in) {
            log::warn("MacroTape: no saved macro found yet");
            return false;
        }

        std::vector<MacroEvent> loaded;
        std::string line;
        while (std::getline(in, line)) {
            if (line.empty() || line[0] == '#') continue;

            std::replace(line.begin(), line.end(), ',', ' ');
            std::istringstream row(line);
            MacroEvent event;
            int down = 0;
            int player2 = 0;

            if (!(row >> event.frame >> event.button >> down >> player2)) continue;
            if (event.frame < 0 || event.button < 0 ||
                (down != 0 && down != 1) ||
                (player2 != 0 && player2 != 1)) {
                continue;
            }

            event.down = down == 1;
            event.player2 = player2 == 1;
            loaded.push_back(event);
        }

        if (loaded.empty()) {
            log::warn("MacroTape: saved macro is empty or invalid");
            return false;
        }

        std::stable_sort(loaded.begin(), loaded.end(),
            [](MacroEvent const& a, MacroEvent const& b) {
                return a.frame < b.frame;
            });

        g_events = std::move(loaded);
        return true;
    }

    void releasePlayers() {
        if (auto layer = PlayLayer::get()) {
            if (layer->m_player1) layer->m_player1->releaseAllButtons();
            if (layer->m_player2) layer->m_player2->releaseAllButtons();
        }
    }

    void stopPlayback() {
        g_playing = false;
        g_playIndex = 0;
        releasePlayers();
    }
}

// Capture the game's actual input calls. Inputs sent by playback are ignored
// by recordEvent while g_playing is true, preventing recursive recording.
class $modify(MacroTapePlayerObject, PlayerObject) {
    bool pushButton(PlayerButton button) {
        bool result = PlayerObject::pushButton(button);
        recordEvent(this, button, true);
        return result;
    }

    bool releaseButton(PlayerButton button) {
        bool result = PlayerObject::releaseButton(button);
        recordEvent(this, button, false);
        return result;
    }
};

class $modify(MacroTapePlayLayer, PlayLayer) {
    void onEnter() {
        PlayLayer::onEnter();

        auto menu = CCMenu::create();
        if (!menu) return;

        auto addButton = [this, menu](char const* label, SEL_MenuHandler callback) {
            auto text = CCLabelBMFont::create(label, "bigFont.fnt");
            if (!text) return;
            text->setScale(0.42f);
            auto item = CCMenuItemLabel::create(text, this, callback);
            if (item) menu->addChild(item);
        };

        addButton("REC", menu_selector(MacroTapePlayLayer::onMacroRecord));
        addButton("SAVE", menu_selector(MacroTapePlayLayer::onMacroSave));
        addButton("LOAD", menu_selector(MacroTapePlayLayer::onMacroLoad));
        addButton("PLAY", menu_selector(MacroTapePlayLayer::onMacroPlay));
        addButton("STOP", menu_selector(MacroTapePlayLayer::onMacroStop));

        menu->alignItemsHorizontallyWithPadding(8.f);
        menu->setPosition({
            CCDirector::sharedDirector()->getWinSize().width / 2.f,
            CCDirector::sharedDirector()->getWinSize().height - 22.f
        });
        menu->setZOrder(10000);
        this->addChild(menu);
    }

    void onMacroRecord(CCObject*) {
        if (g_playing) {
            FLAlertLayer::create("MacroTape", "Stop playback before recording.", "OK")->show();
            return;
        }

        if (!g_recording) {
            g_events.clear();
            g_frame = 0;
            g_recording = true;
            FLAlertLayer::create("MacroTape", "Recording started. Tap REC again to stop.", "OK")->show();
        } else {
            g_recording = false;
            FLAlertLayer::create("MacroTape", "Recording stopped. Tap SAVE to store it.", "OK")->show();
        }
    }

    void onMacroSave(CCObject*) {
        if (g_recording || g_playing) {
            FLAlertLayer::create("MacroTape", "Stop recording/playback before saving.", "OK")->show();
            return;
        }
        bool ok = saveMacro();
        FLAlertLayer::create("MacroTape", ok ? "Macro saved." : "Could not save macro.", "OK")->show();
    }

    void onMacroLoad(CCObject*) {
        if (g_recording || g_playing) {
            FLAlertLayer::create("MacroTape", "Stop recording/playback first.", "OK")->show();
            return;
        }
        bool ok = loadMacro();
        FLAlertLayer::create("MacroTape", ok ? "Macro loaded." : "No valid macro found.", "OK")->show();
    }

    void onMacroPlay(CCObject*) {
        if (g_recording || g_playing) {
            FLAlertLayer::create("MacroTape", "Stop recording/playback first.", "OK")->show();
            return;
        }
        if (g_events.empty() && !loadMacro()) {
            FLAlertLayer::create("MacroTape", "No macro loaded. Record and save one first.", "OK")->show();
            return;
        }

        g_frame = 0;
        g_playIndex = 0;
        g_playing = true;
        FLAlertLayer::create("MacroTape", "Playback started from the current position. Test offline.", "OK")->show();
    }

    void onMacroStop(CCObject*) {
        g_recording = false;
        stopPlayback();
        FLAlertLayer::create("MacroTape", "Recording/playback stopped.", "OK")->show();
    }

    void update(float dt) {
        PlayLayer::update(dt);

        if (g_playing) {
            while (g_playIndex < g_events.size() &&
                   g_events[g_playIndex].frame <= g_frame) {
                auto const event = g_events[g_playIndex++];
                auto player = event.player2 ? m_player2 : m_player1;
                if (!player) continue;

                auto button = static_cast<PlayerButton>(event.button);
                if (event.down) player->pushButton(button);
                else player->releaseButton(button);
            }

            if (g_playIndex >= g_events.size()) {
                stopPlayback();
                log::info("MacroTape: playback finished");
            }
        }

        if (g_recording || g_playing) ++g_frame;
    }

    void onExit() {
        g_recording = false;
        stopPlayback();
        PlayLayer::onExit();
    }
};
